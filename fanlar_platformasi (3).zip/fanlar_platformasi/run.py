"""Veb saytni brauzerda ochadi: python run.py"""
import pathlib
import webbrowser

webbrowser.open(pathlib.Path(__file__).with_name("index.html").resolve().as_uri())
