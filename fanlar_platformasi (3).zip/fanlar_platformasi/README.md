# Fanlar bo'yicha ma'lumot platformasi

DevOps va CI/CD fanining amaliy loyihasi. Asosiy texnologiya: **Git** (+ GitHub Actions).
Texnologiya: HTML + CSS + JavaScript (obyektga yo'naltirilgan, ES6 classlar).
Talaba: Do'stbekova Charos Doniyor qizi.

## Ishga tushirish
- `run.bat` ni ikki marta bosing (Windows) yoki `python run.py` ni ishga tushiring: sayt brauzerda ochiladi.
- Yoki to'g'ridan-to'g'ri `index.html` ni brauzerda oching.
- Onlayn: `https://<login>.github.io/fanlar-platformasi/` (push qilinganda GitHub Actions avtomatik joylaydi).

## Imkoniyatlar
- Fanlar ro'yxati, qidirish, semestr bo'yicha filtr
- Fan qo'shish (kiritilgan ma'lumotlar tekshiriladi) va o'chirish
- O'qituvchi qo'shish va fanga biriktirish
- Fanga o'quv resurslari (darslik, video, havola) qo'shish
- Statistika (fanlar soni, kredit, semestr bo'yicha grafik)
- Ma'lumotlar brauzer `localStorage` xotirasida saqlanadi

## Loyiha tuzilmasi
```
index.html                    # sayt: interfeys + classlar
run.py, run.bat               # saytni brauzerda ochish
.github/workflows/pages.yml   # CI/CD: GitHub Pages'ga avtomatik joylash
```

## Arxitektura sxemasi
```mermaid
flowchart LR
    U[Foydalanuvchi] --> UI[Interfeys<br/>sahifalar va hodisalar]
    UI --> SVC[FanService<br/>biznes mantiq]
    SVC --> MOD[Fan, Oqituvchi, Resurs]
    SVC --> REPO[LocalStorageRepo]
    REPO --> LS[(localStorage)]
    GIT[Git push] --> CI[GitHub Actions] --> PAGES[GitHub Pages sayti]
```
Qatlamlar: interfeys -> biznes mantiq -> saqlash.

## UML: Use Case diagrammasi
```mermaid
flowchart LR
    F((Foydalanuvchi))
    F --- A([Fanlar ro'yxatini ko'rish])
    F --- B([Fan qidirish va filtrlash])
    F --- C([Fan qo'shish])
    F --- D([Fanni o'chirish])
    F --- E([O'qituvchi biriktirish])
    F --- G([Resurs qo'shish])
    F --- H([Statistikani ko'rish])
```

## UML: Class diagrammasi
```mermaid
classDiagram
    class Fan {
        +String kod
        +String nomi
        +String kafedra
        +Number kredit
        +Number soat
        +Number semestr
        +Number oqituvchiId
        +String tavsif
        +Resurs[] resurslar
    }
    class Oqituvchi {
        +Number id
        +String ism
        +String kafedra
    }
    class Resurs {
        +String nomi
        +String turi
        +String havola
    }
    class LocalStorageRepo {
        +String key
        +load()
        +save(data)
    }
    class FanService {
        +fanQoshish(d)
        +fanOlish(kod)
        +fanOchirish(kod)
        +royxat(q, sem)
        +oqituvchiQoshish(ism, kafedra)
        +biriktirish(kod, id)
        +resursQoshish(kod, nomi, turi, havola)
        +statistika()
    }
    class ValidationError
    FanService o-- Fan
    FanService o-- Oqituvchi
    FanService --> LocalStorageRepo
    Fan *-- Resurs
    Fan --> Oqituvchi : oqituvchiId
    FanService ..> ValidationError
```

## UML: Sequence diagrammasi (fan qo'shish)
```mermaid
sequenceDiagram
    actor U as Foydalanuvchi
    participant UI as Interfeys
    participant S as FanService
    participant F as Fan
    participant R as LocalStorageRepo
    U->>UI: Formani to'ldirib "Saqlash"ni bosadi
    UI->>S: fanQoshish(malumot)
    S->>F: new Fan(malumot) tekshiruv
    F-->>S: obyekt yoki ValidationError
    S->>R: save(data)
    R-->>S: saqlandi
    S-->>UI: Fan
    UI-->>U: Fan sahifasi ochiladi
```

## Git bilan ishlash
```bash
git init
git branch -M main
git add . && git commit -m "Loyiha qo'shildi"
git remote add origin https://github.com/<login>/fanlar-platformasi.git
git push -u origin main

git checkout -b feature/tahrirlash
git add . && git commit -m "Yangi funksiya"
git push -u origin feature/tahrirlash   # GitHub'da Pull Request ochib merge qilinadi
```
GitHub'da **Settings -> Pages -> Source: GitHub Actions** ni tanlang. Shundan keyin har bir push sayt'ni avtomatik yangilaydi.
